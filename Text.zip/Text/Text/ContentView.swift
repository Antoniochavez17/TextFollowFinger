//
//  ContentView.swift
//  Text
//
//  Created by Antonio Adrian Chavez on 4/26/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    let Letters = ["H", "e", "l", "l", "o", ",", "  S","w","i","f","t","U","I"]
    
    @State private var enabled = false
    @State private var dramamount = CGSize.zero
    
    
    var body: some View {
    
        HStack(spacing: 0) {
            ForEach(0..<Letters.count) {num in
                Text(String(self.Letters[num]))
                .padding(5)
                .font(.title)
                    .background(self.enabled ? Color.blue : Color.red)
                    .offset(self.dramamount)
                    .animation(Animation.default.delay(Double(num) / 20))
                
            }
            
        }
        
        
        .gesture(
                
                DragGesture()
                    .onChanged { self.dramamount = $0.translation  }
                        
                    .onEnded {_ in
                            
                            self.dramamount = .zero
                            self.enabled.toggle()
                }
                
                
                
            
                )
            
        }

        
        }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
